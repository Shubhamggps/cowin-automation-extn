const phone_number_9_digits = "999999990";
const state_name = "Madhya Pradesh";
const district_name = "Agar";

// if this is true, Schedule Now button will have to be manually clicked
const allow_multiple = false; // put true if you want it to allow registration for multiple people


// I recommend you keep this empty, else you will always have to remove 5 digits if you wish to change pin
const first_5_pin_digits = ""; 